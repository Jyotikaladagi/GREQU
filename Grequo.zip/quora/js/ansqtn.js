function openFormb() {
    document.getElementById("myForm1").style.display = "block";
  }
  
  function closeFormb() {
    document.getElementById("myForm1").style.display = "none";
  }